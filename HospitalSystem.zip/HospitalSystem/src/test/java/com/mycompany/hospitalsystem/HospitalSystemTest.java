/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.hospitalsystem;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class HospitalSystemTest {

    @Test
    public void testRegisterPatient() {
        PatientManager pm = new PatientManager();
        Patient p = new Patient("P01", "John", "Doe", 30, "Male", "Flu", PatientCategory.OUTPATIENT);
        assertTrue(pm.registerPatient(p));
    }

    @Test
    public void testPreventDuplicateIds() {
        PatientManager pm = new PatientManager();
        Patient p1 = new Patient("P01", "John", "Doe", 30, "Male", "Flu", PatientCategory.OUTPATIENT);
        Patient p2 = new Patient("P01", "Jane", "Doe", 25, "Female", "Cold", PatientCategory.OUTPATIENT);
        pm.registerPatient(p1);
        assertFalse(pm.registerPatient(p2));
    }

    @Test
    public void testSearchPatient() {
        PatientManager pm = new PatientManager();
        pm.registerPatient(new Patient("P02", "A", "B", 20, "M", "X", PatientCategory.EMERGENCY));
        assertNotNull(pm.searchPatient("P02"));
    }

    @Test
    public void testDeletePatient() {
        PatientManager pm = new PatientManager();
        pm.registerPatient(new Patient("P03", "A", "B", 20, "M", "X", PatientCategory.OUTPATIENT));
        assertTrue(pm.deletePatient("P03"));
    }

    @Test
    public void testAllocateBed() {
        BedManager bm = new BedManager();
        assertTrue(bm.allocateBed("B01"));
    }

    @Test
    public void testPreventAllocatingOccupiedBed() {
        BedManager bm = new BedManager();
        bm.allocateBed("B01");
        assertFalse(bm.allocateBed("B01"));
    }

    @Test
    public void testReleaseBed() {
        BedManager bm = new BedManager();
        bm.allocateBed("B02");
        assertTrue(bm.releaseBed("B02"));
    }

    @Test
    public void testIsWardFull() {
        BedManager bm = new BedManager();
        for (int i = 1; i <= 20; i++) {
            bm.allocateBed(String.format("B%02d", i));
        }
        assertTrue(bm.isWardFull());
    }

    @Test
    public void testSortBySurname() {
        PatientManager pm = new PatientManager();
        pm.registerPatient(new Patient("P10", "John", "Zebra", 30, "M", "X", PatientCategory.OUTPATIENT));
        pm.registerPatient(new Patient("P11", "John", "Apple", 30, "M", "X", PatientCategory.OUTPATIENT));
        pm.sortBySurname();
        assertEquals("Apple", pm.getPatients().get(0).getLastName());
    }
}