/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalsystem;
public class BedManager {
    private String[][] beds = new String[4][5]; // 20 beds
    private boolean[][] occupied = new boolean[4][5];

    public BedManager() {
        int count = 1;
        for (int i = 0; i < beds.length; i++) { // nested loops
            for (int j = 0; j < beds[i].length; j++) {
                beds[i][j] = String.format("B%02d", count);
                occupied[i][j] = false;
                count++;
            }
        }
    }

    // Passing array to method + length field
    public void displayLayout(String[][] bedArray) {
        System.out.println("\n--- WARD LAYOUT (4x5) ---");
        for (int i = 0; i < bedArray.length; i++) {
            for (int j = 0; j < bedArray[i].length; j++) {
                String status = occupied[i][j]? "[X]" : "[ ]";
                System.out.print(bedArray[i][j] + status + " ");
            }
            System.out.println();
        }
    }

    public String[][] getBeds() { return beds; }

    public boolean allocateBed(String bedId) {
        for (int i = 0; i < beds.length; i++) {
            for (int j = 0; j < beds[i].length; j++) {
                if (beds[i][j].equalsIgnoreCase(bedId)) {
                    if (occupied[i][j]) return false; // Prevent allocating occupied bed
                    occupied[i][j] = true;
                    return true;
                }
            }
        }
        return false;
    }

    public boolean releaseBed(String bedId) {
        for (int i = 0; i < beds.length; i++) {
            for (int j = 0; j < beds[i].length; j++) {
                if (beds[i][j].equalsIgnoreCase(bedId)) {
                    if (!occupied[i][j]) return false;
                    occupied[i][j] = false;
                    return true;
                }
            }
        }
        return false;
    }

    public void displayAvailableBeds() {
        System.out.println("Available Beds:");
        for (int i = 0; i < beds.length; i++) {
            for (int j = 0; j < beds[i].length; j++) {
                if (!occupied[i][j]) System.out.print(beds[i][j] + " ");
            }
        }
        System.out.println();
    }

    public void displayOccupiedBeds() {
        System.out.println("Occupied Beds:");
        for (int i = 0; i < beds.length; i++) {
            for (int j = 0; j < beds[i].length; j++) {
                if (occupied[i][j]) System.out.print(beds[i][j] + " ");
            }
        }
        System.out.println();
    }

    public int getTotalOccupied() {
        int count = 0;
        for (boolean[] row : occupied) {
            for (boolean b : row) if (b) count++;
        }
        return count;
    }

    public boolean isWardFull() {
        return getTotalOccupied() == 20;
    }
}