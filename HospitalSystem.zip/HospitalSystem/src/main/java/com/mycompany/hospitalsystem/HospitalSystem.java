/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hospitalsystem;
import java.util.Scanner;

public class HospitalSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PatientManager pm = new PatientManager();
        BedManager bm = new BedManager();
        int choice = 0;

        do {
            try {
                System.out.println("\n=== MediCare Hospital Patient Admission System ===");
                System.out.println("1. Register New Patient");
                System.out.println("2. Search Patient by ID");
                System.out.println("3. Update Patient");
                System.out.println("4. Delete Patient");
                System.out.println("5. Display All Patients");
                System.out.println("6. Allocate Bed (Inpatient only)");
                System.out.println("7. Release Bed");
                System.out.println("8. Display Ward Layout");
                System.out.println("9. Display Available Beds");
                System.out.println("10. Display Occupied Beds");
                System.out.println("11. Reports");
                System.out.println("12. Sort by Surname");
                System.out.println("13. Sort by Patient ID");
                System.out.println("0. Exit");
                System.out.print("Enter choice: ");
                choice = Integer.parseInt(sc.nextLine());

                switch (choice) {
                    case 1:
                        System.out.print("Patient ID: "); String id = sc.nextLine();
                        System.out.print("First Name: "); String fn = sc.nextLine();
                        System.out.print("Last Name: "); String ln = sc.nextLine();
                        System.out.print("Age: "); int age = Integer.parseInt(sc.nextLine());
                        System.out.print("Gender: "); String gender = sc.nextLine();
                        System.out.print("Medical Condition: "); String cond = sc.nextLine();
                        System.out.println("Category: "); PatientCategory.displayCategories();
                        System.out.print("Choose 0,1,2: "); int catChoice = Integer.parseInt(sc.nextLine());
                        PatientCategory cat = PatientCategory.values()[catChoice];

                        Patient p;
                        if (cat == PatientCategory.INPATIENT) {
                            p = new Inpatient(id, fn, ln, age, gender, cond, 1, "Not Allocated");
                        } else {
                            p = new Patient(id, fn, ln, age, gender, cond, cat);
                        }
                        if (pm.registerPatient(p)) System.out.println("Patient Registered!");
                        else System.out.println("Duplicate ID! Registration failed.");
                        break;
                    case 2:
                        System.out.print("Enter ID: "); Patient found = pm.searchPatient(sc.nextLine());
                        if (found!= null) found.displayDetails(); else System.out.println("Not found");
                        break;
                    case 6:
                        if (bm.isWardFull()) { System.out.println("No beds available! Ward full."); break; }
                        System.out.print("Enter Patient ID (Inpatient): "); String pid = sc.nextLine();
                        Patient ip = pm.searchPatient(pid);
                        if (ip == null || ip.getCategory()!= PatientCategory.INPATIENT) {
                            System.out.println("Only Inpatients can be allocated a bed.");
                            break;
                        }
                        bm.displayAvailableBeds();
                        System.out.print("Enter Bed ID e.g. B01: "); String bedId = sc.nextLine();
                        if (bm.allocateBed(bedId)) {
                            ((Inpatient) ip).setBedNumber(bedId);
                            System.out.println("Bed " + bedId + " allocated to " + pid);
                        } else System.out.println("Bed already occupied or invalid!");
                        break;
                    case 7:
                        System.out.print("Enter Bed ID to release: "); String rel = sc.nextLine();
                        if (bm.releaseBed(rel)) System.out.println("Bed released"); else System.out.println("Failed");
                        break;
                    case 8: bm.displayLayout(bm.getBeds()); break;
                    case 9: bm.displayAvailableBeds(); break;
                    case 10: bm.displayOccupiedBeds(); break;
                    case 11:
                        System.out.println("\n--- WARD REPORTS ---");
                        System.out.println("Total registered: " + pm.getTotalPatients());
                        System.out.println("Total occupied beds: " + bm.getTotalOccupied());
                        double occ = (bm.getTotalOccupied() / 20.0) * 100;
                        System.out.println("Ward occupancy %: " + occ + "%");
                        pm.displayAllPatients();
                        break;
                    case 12: pm.sortBySurname(); break;
                    case 13: pm.sortByPatientId(); break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format! Try again.");
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Invalid category choice!");
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (choice!= 0);
        sc.close();
    }
}