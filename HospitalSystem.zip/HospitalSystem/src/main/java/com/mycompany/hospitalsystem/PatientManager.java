/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalsystem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PatientManager {
    private ArrayList<Patient> patients = new ArrayList<>();

    public boolean registerPatient(Patient p) {
        // Prevent duplicate IDs
        if (searchPatient(p.getPatientId())!= null) {
            return false;
        }
        patients.add(p);
        return true;
    }

    public Patient searchPatient(String id) {
        for (Patient p : patients) {
            if (p.getPatientId().equalsIgnoreCase(id)) return p;
        }
        return null;
    }

    public boolean deletePatient(String id) {
        Patient p = searchPatient(id);
        if (p!= null) {
            patients.remove(p);
            return true;
        }
        return false;
    }

    public boolean updatePatient(String id, String newFirst, String newLast, int newAge) {
        Patient p = searchPatient(id);
        if (p!= null) {
            p.setFirstName(newFirst);
            p.setLastName(newLast);
            p.setAge(newAge);
            return true;
        }
        return false;
    }

    public void displayAllPatients() {
        if (patients.isEmpty()) {
            System.out.println("No patients registered.");
            return;
        }
        for (Patient p : patients) p.displayDetails();
    }

    // Sorting Arrays - Requirement
    public void sortBySurname() {
        Collections.sort(patients, Comparator.comparing(Patient::getLastName));
        System.out.println("Sorted by surname:");
        displayAllPatients();
    }

    public void sortByPatientId() {
        Collections.sort(patients, Comparator.comparing(Patient::getPatientId));
        System.out.println("Sorted by Patient ID:");
        displayAllPatients();
    }

    public int getTotalPatients() { return patients.size(); }
    public ArrayList<Patient> getPatients() { return patients; }
}