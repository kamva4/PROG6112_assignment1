/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.hospitalsystem;
public enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY;

    // Enum methods - required by rubric
    public static void displayCategories() {
        for (PatientCategory cat : PatientCategory.values()) {
            System.out.println(cat.ordinal() + " - " + cat.name());
        }
    }
}